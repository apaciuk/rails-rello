const config = require('./jest.config')
config.testMatch = ['**/*.spec.js']
module.exports = config