module.exports = {
    coverageDirectory: 'coverage',
    testEnvironment: 'node',
    collectCoverageFrom: ['jkanban.js']
  }